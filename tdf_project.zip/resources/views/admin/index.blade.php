@extends('admin.toolbar')
@section('content')
    @csrf
@endsection
