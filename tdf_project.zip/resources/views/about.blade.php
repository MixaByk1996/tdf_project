@extends('layouts.app')
@section('title-block')О нас@endsection
@section('content')
    <section class="error-section">
        <div class="error-container-main">
            <h3 class="error-maintext">О нас</h3>
            <div class="aboutUS-descr">Мы - ваш надежный интернет-магазин TDF - "Торговый дом Фурнитуры", где реализуются ваши мебельные идеи. Сотрудничаем с лучшими производителями, обеспечивая высокое качество каждого товара. Широкий ассортимент нашего каталога включает эксклюзивные ручки, ноги, петли и многое другое для вашей мебели. 
Оформите заказ онлайн и получите удобную доставку до места назначения. 
TDF - Комфорт в каждой детали</div>
        </div>
    </section>
@endsection
