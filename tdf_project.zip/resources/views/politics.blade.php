@extends('layouts.app')
@section('title-block')Политика конфиденциальности@endsection
@section('content')
    <section class="error-section">
        <div class="error-container-main">
            <h3 class="error-maintext">Политика конфиденциальности</h3>
        </div>
    </section>
@endsection
