<html>
<body>
<p>Имя: {{$name}}</p>
<p>Номер телефона: {{$phone}}</p>
<p>Вопрос: {{$description}}</p>
</body>
</html>
