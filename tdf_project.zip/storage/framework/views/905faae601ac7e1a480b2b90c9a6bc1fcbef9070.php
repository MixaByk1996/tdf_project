<html>
<body>
    <p>Имя: <?php echo e($name); ?></p>
    <p>Номер телефона: <?php echo e($phone); ?></p>
    <p>Вопрос: <?php echo e($description); ?></p>
</body>
</html>
<?php /**PATH E:\tests_project\tdf_project\resources\views/send-question.blade.php ENDPATH**/ ?>