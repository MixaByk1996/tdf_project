<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <meta name="format-detection" content="telephone=no">

    
    <script src="/js/jquery.js"></script>
    <script src="/js/marquee.js"></script>
    <script type="text/javascript" src="/js/validate.js"></script>
    <script src="/js/main.js"></script>

    <script src="/js/filterFavorite.js"></script>
    <script src="/js/catalog.js"></script>
    <script src="/js/slider.js"></script>

    <script src="/js/filterCatalog.js"></script>
    <script src="/js/modalCart.js"></script>
    <script src="/js/modalCart2.js"></script>
    <script src="/js/modalCart3.js"></script>
    <script src="/js/modalCart4.js"></script>
    <script src="/js/modalCart5.js"></script>

    <script src="/js/quantity.js"></script>

    <script src="/js/cabinet.js"></script>
    <script src="/js/home.js"></script>
    <script src="/js/burgerMenu.js"></script>


    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/media.css">
    <link rel="stylesheet" href="../../css/app.css">
    <title><?php echo $__env->yieldContent('title-block'); ?></title>
</head>
<body>
<div class="adaptive">
    <?php echo $__env->make('inc.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    
    
    
    
    
    <?php echo $__env->make('inc.appeal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

</body>
</html>
<?php /**PATH E:\tests_project\tdf_project\resources\views/layouts/app.blade.php ENDPATH**/ ?>