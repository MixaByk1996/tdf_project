<?php $__env->startSection('content'); ?>
    <?php echo csrf_field(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\tests_project\tdf_project\resources\views/admin/index.blade.php ENDPATH**/ ?>