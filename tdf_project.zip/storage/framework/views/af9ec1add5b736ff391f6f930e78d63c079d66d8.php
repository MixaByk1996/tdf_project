
<?php $__env->startSection('content'); ?>
    <?php echo csrf_field(); ?>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Продукты</h2>
                </div>
                <div class="pull-right mb-2">
                    <a class="btn btn-success" href="<?php echo e(route('admin-products.create')); ?>"> Добавить</a>
                </div>
            </div>
            <form action="<?php echo e(route('products-search')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-lg-12 margin-tb">
                    <div class="pull-left">
                        <h2>Введите артикул для поиска</h2>
                    </div>
                    <div class="pull-left">
                        <input type="text" name="search" id="search" class="form-control" required placeholder="Введите артикул">
                    </div>
                    <div class="pull-right mb-2">
                        <input type="submit" class="btn btn-success" value="Найти">
                    </div>
                </div>
            </form>
            <div class="container mt-5">
                <h2>Загрузить файл</h2>
                <form action="<?php echo e(route('upload-file-excel')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input class="form-control" type="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" name="file">
                    </div>
                    <button type="submit" class="btn btn-primary">Загрузить</button>
                </form>
            </div>

        </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Фото</th>
                <th>Артикул</th>
                <th>Наименование</th>
                <th>Модель</th>
                <th>Цена</th>
                <th>Валюта</th>
                <th>Производитель</th>
                <th>Опт ТДФ</th>
                <th>ТД розница</th>
                <th>Вес</th>
                <th>Штрихкод</th>
                <th >Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><img width="100" height="100" src="http://5.35.94.70/storage/<?php echo e($item->image_path); ?>"></td>
                    <td><?php echo e($item->article ?? 'Отсувствуют данные'); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->model); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->currency); ?></td>
                    <td><?php echo e($item->producer->name ?? 'Отсувствуют данные'); ?></td>
                    <td><?php echo e($item->tdf); ?></td>
                    <td><?php echo e($item->tdf_ros); ?></td>
                    <td><?php echo e($item->ves); ?></td>
                    <td><?php echo e($item->barcode); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin-products.destroy', $item->id)); ?>" method="Post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Удалить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $products->links('pagination::tailwind'); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\tests_project\tdf_project\resources\views/admin/products/index.blade.php ENDPATH**/ ?>