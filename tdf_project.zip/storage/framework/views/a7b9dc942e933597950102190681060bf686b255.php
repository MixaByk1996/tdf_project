<?php if($paginator->lastPage() > 1): ?>
    <select class="pagination">
        <option data-url="<?php echo e($paginator->url(1)); ?>" onclick="window.location.assign('<?php echo e($paginator->url(1)); ?>')" <?php echo e(($paginator->currentPage() == 1) ? 'selected' : ''); ?>>
            <a href="<?php echo e($paginator->url(1)); ?>">В начало</a>
        </option>
        <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
            <option data-url="<?php echo e($paginator->url($i)); ?>"  onclick="window.location.assign('<?php echo e($paginator->url($i)); ?>')" <?php echo e(($paginator->currentPage() == $i) ? 'selected' : ''); ?>>
                <a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            </option>
        <?php endfor; ?>
        <option  data-url="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>"  onclick="window.location.assign('<?php echo e($paginator->url($paginator->currentPage()+1)); ?>')" <?php echo e(($paginator->currentPage() == $paginator->lastPage()) ? 'selected' : ''); ?>>
            <a href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>" >Следующее</a>
        </option>
    </select>

<?php endif; ?>

<?php /**PATH E:\tests_project\tdf_project\resources\views/vendor/pagination/custom_pagination.blade.php ENDPATH**/ ?>